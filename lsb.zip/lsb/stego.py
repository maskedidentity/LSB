from stegano import lsb
import argparse
import sys
import random
import re
from flask import Flask, render_template, request
from werkzeug.utils import secure_filename


app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/embed', methods=['POST'])
def embed():
    try:
        file = request.files['file']
        message = request.form['message']
        password = request.form.get('password', 'no_password_given')

        if file.filename == '':
            return "Please select a file."

        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file_path = 'uploads/' + filename
            file.save(file_path)

            embed_data = password + " " + message
            secret = lsb.hide(file_path, embed_data)

            random_number = random.randint(0, 100)
            secret_filename = "secret" + str(random_number) + ".png"
            secret.save(secret_filename)

            return "File saved as " + secret_filename

    except Exception as e:
        return "Error: " + str(e)

@app.route('/extract', methods=['POST'])
def extract():
    try:
        file = request.files['file']
        password = request.form.get('password', '')

        if file.filename == '':
            return "Please select a file."

        if file and allowed_file(file.filename):
            file_path = 'uploads/' + secure_filename(file.filename)
            file.save(file_path)

            message = lsb.reveal(file_path)

            if password and len(re.findall(r'\b'+password+r'\b', message)) != 0:
                message = message.replace(password, "")
                return "The secret message is: " + message
            else:
                return "Couldn't reveal the message with the provided password."

    except Exception as e:
        return "Error: " + str(e)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() == 'png'

if __name__ == '__main__':
    app.run(debug=True)

