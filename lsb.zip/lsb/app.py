from flask import Flask, render_template, request
from werkzeug.utils import secure_filename
from stegano import lsb
import os
import random
import re
import sys

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
ALLOWED_EXTENSIONS = {'png'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/embed', methods=['POST'])
def embed():
    try:
        file = request.files['file']
        message = request.form['message']
        password = request.form.get('password', 'no_password_given')

        if file.filename == '' or not allowed_file(file.filename):
            return "Please select a valid PNG file."

        filename = secure_filename(file.filename)
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(file_path)

        embed_data = password + " " + message
        secret = lsb.hide(file_path, embed_data)

        random_number = random.randint(0, 100)
        secret_filename = "secret" + str(random_number) + ".png"
        secret_path = os.path.join(app.config['UPLOAD_FOLDER'], secret_filename)
        secret.save(secret_path)

        return "File saved as " + secret_filename

    except Exception as e:
        return "Error: " + str(e)

@app.route('/extract', methods=['POST'])
def extract():
    try:
        file = request.files['file']
        password = request.form.get('password', '')

        if file.filename == '' or not allowed_file(file.filename):
            return "Please select a valid PNG file."

        file_path = os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(file.filename))
        file.save(file_path)

        message = lsb.reveal(file_path)

        if not password:
            return "The secret message is: " + message
        elif len(re.findall(r'\b'+password+r'\b', message)) != 0:
            message = message.replace(password, "")
            return "The secret message is: " + message
        else:
            return "Couldn't reveal the message with the provided password."

    except Exception as e:
        return "Error: " + str(e)

if __name__ == '__main__':
    app.run(debug=True)









